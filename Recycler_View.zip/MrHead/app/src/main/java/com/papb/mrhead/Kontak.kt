package com.papb.mrhead

class Kontak(name: String, number: String, image: Int) {
    var _name: String
    var _image: Int
    var _number: String

    init {
        _name = name
        _number = number
        _image = image
    }
}