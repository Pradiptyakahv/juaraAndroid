package com.papb.mrhead

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class Register: AppCompatActivity(), View.OnClickListener {
    lateinit var _username: EditText
    lateinit var _email: EditText
    lateinit var _pass: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)

        val _btReg = findViewById<Button>(R.id.register_button)
        _btReg.setOnClickListener(this)
        _username = findViewById<EditText>(R.id.username)
        _email = findViewById<EditText>(R.id.email_register)
        _pass = findViewById<EditText>(R.id.password_register)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.register_button -> {
                var usernameFilled: Boolean = _username.text.toString() != ""
                var emailFilled: Boolean = _email.text.toString() != ""
                var passFilled: Boolean = _pass.text.toString() != ""

                if (!usernameFilled) {
                    _username.setError("Please enter username")
                }
                if (!emailFilled) {
                    _email.setError("Please enter email")
                }
                if (!passFilled) {
                    _pass.setError("Please enter password")
                }
                else if (usernameFilled && emailFilled && passFilled){
                    var result = Intent()
                    result.putExtra("username", _username.text.toString())
                    result.putExtra("email", _email.text.toString())
                    result.putExtra("pass", _pass.text.toString())

                    setResult(RESULT_OK, result)

                    finish()
                }
            }
        }
    }
}