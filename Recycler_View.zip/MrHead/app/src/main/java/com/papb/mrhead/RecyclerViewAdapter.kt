package com.papb.mrhead

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class RecyclerViewAdapter(_kontakList: ArrayList<Kontak>, _context: Context) : RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>() {

    private var _kontakList: ArrayList<Kontak>
    private var _context: Context

    init {
        this._kontakList = _kontakList
        this._context = _context
    }

    class ViewHolder(v : View) : RecyclerView.ViewHolder(v), View.OnClickListener {
        var _context: Context
        var _txName: TextView
        var _txNumber: TextView
        var _image: ImageView

        init {
            _context = itemView.context
            _txName = itemView.findViewById<TextView>(R.id.name)
            _txNumber = itemView.findViewById<TextView>(R.id.number)
            _txNumber.setOnClickListener(this)
            _image = itemView.findViewById<ImageView>(R.id.image)
        }

        override fun onClick(v: View?) {
            val uri = Uri.parse("tel:" + _txNumber.getText().toString())
            val it = Intent(Intent.ACTION_DIAL, uri)
            _context.startActivity(it)
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.layout_item, viewGroup, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder._txName.setText(_kontakList[position]._name)
        Glide.with(_context).load(_kontakList[position]._image).into(holder._image)
        holder._txNumber.setText(_kontakList[position]._number)
    }

    override fun getItemCount(): Int {
        return _kontakList.size
    }
}