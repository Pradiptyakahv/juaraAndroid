package com.papb.mrhead

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class Login : AppCompatActivity(), View.OnClickListener {
    var _tempEmail = ""
    var _tempPass = ""
    var _tempUsername = ""
    lateinit var _txEmail: EditText
    lateinit var _txPass: EditText
    var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            if (data?.getStringExtra("from").toString() == "logout") {
                Toast.makeText(this, _tempUsername + " has logged out", Toast.LENGTH_LONG).show()
            }
            else {
                _tempUsername = data?.getStringExtra("username").toString()
                _tempEmail = data?.getStringExtra("email").toString()
                _txEmail.setText(_tempEmail)
                _tempPass = data?.getStringExtra("pass").toString()
                Toast.makeText(this, "You are registered!", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        val _btLogin = findViewById<Button>(R.id.login_button)
        val _btReg = findViewById<TextView>(R.id.register_text2)
        _txEmail = findViewById<EditText>(R.id.email_form)
        _txPass = findViewById<EditText>(R.id.password_form)

        _btLogin.setOnClickListener(this)
        _btReg.setOnClickListener(this)

        Log.d("Demo", "masuk ke onCreate")
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.login_button -> {
                var emailTrue: Boolean = _txEmail.text.toString() == _tempEmail
                var passTrue: Boolean = _txPass.text.toString() == _tempPass

                if (emailTrue && _tempEmail != "") {
                    if (passTrue && _tempPass != "") {
                        var intent = Intent(this, Homepage::class.java)
                        intent.putExtra("username", _tempUsername)
                        resultLauncher.launch(intent)
                    }
                }
                if (_txEmail.text.toString() == "") {
                    _txEmail.setError("Please enter email")
                }
                if (_txPass.text.toString() == "") {
                    _txPass.setError("Please enter password")
                }
                if (!emailTrue) {
                    _txEmail.setError("Wrong email")
                }
                if (!passTrue) {
                    _txPass.setError("Wrong password")
                }
            }

            R.id.register_text2 -> {
                var intent = Intent(this, Register::class.java)
                resultLauncher.launch(intent)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("Demo", "masuk ke onStart")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Demo", "masuk ke onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Demo", "masuk ke onDestroy")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Demo", "masuk ke onRestart")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Demo", "masuk ke onPause")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Demo", "masuk ke onResume")
    }
}
