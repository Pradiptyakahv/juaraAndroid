package com.papb.mrhead

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.URLEncoder

class Homepage : AppCompatActivity(), View.OnClickListener {
    lateinit var welcome_text: TextView
    lateinit var text: String
    lateinit var username: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.homepage)

        val intent = getIntent()
        username = intent.getStringExtra("username").toString()
        text = "Welcome, " + username + "!"
        welcome_text = findViewById<TextView>(R.id.welcome_homepage)
        welcome_text.setText(text)

        val logout = findViewById<Button>(R.id.logout)
        logout.setOnClickListener(this)

        val contact = findViewById<Button>(R.id.contact)
        contact.setOnClickListener(this)

        val mrHead = findViewById<Button>(R.id.mr_head)
        mrHead.setOnClickListener(this)

        val recycler = findViewById<Button>(R.id.recycler)
        recycler.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.logout -> {
                val intent = Intent()
                intent.putExtra("from", "logout")

                setResult(RESULT_OK, intent)
                finish()
            }

            R.id.contact -> {
                val number = "6285966324623"
                val message = "I want to ask about Mr Head"
                val url = "https://api.whatsapp.com/send?phone=$number"+"&text=" + URLEncoder.encode(message, "UTF-8")
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)
            }

            R.id.mr_head -> {
                var intent = Intent(this, MrHead::class.java)
                intent.putExtra("username", username)
                startActivity(intent)
            }

            R.id.recycler -> {
                var intent = Intent(this, Recycler::class.java)
                intent.putExtra("username", username)
                startActivity(intent)
            }
        }
    }
}