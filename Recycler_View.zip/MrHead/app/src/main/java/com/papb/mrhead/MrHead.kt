package com.papb.mrhead

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import java.net.URLEncoder

class MrHead : AppCompatActivity(), View.OnClickListener {
    lateinit var welcome_text: TextView
    lateinit var text: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mr_head)

        val intent = getIntent()
        text = intent.getStringExtra("username").toString() + "'s Mr Head!"
        welcome_text = findViewById<TextView>(R.id.welcome_mrhead)
        welcome_text.setText(text)

        val janggut = findViewById<CheckBox>(R.id.janggut)
        janggut.setOnClickListener(this)

        val kumis = findViewById<CheckBox>(R.id.kumis)
        kumis.setOnClickListener(this)

        val alis = findViewById<CheckBox>(R.id.alis)
        alis.setOnClickListener(this)

        val rambut = findViewById<CheckBox>(R.id.rambut)
        rambut.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        if (v is CheckBox) {
            val checked : Boolean = v.isChecked

            when (v.id) {
                R.id.janggut -> {
                    val beard = findViewById<ImageView>(R.id.beard)
                    if (checked) {
                        beard.visibility = View.VISIBLE
                    }
                    else {
                        beard.visibility = View.INVISIBLE
                    }
                }

                R.id.kumis -> {
                    val moustache = findViewById<ImageView>(R.id.moustache)
                    if (checked) {
                        moustache.visibility = View.VISIBLE
                    }
                    else {
                        moustache.visibility = View.INVISIBLE
                    }
                }

                R.id.alis -> {
                    val eyebrow = findViewById<ImageView>(R.id.eyebrow)
                    if (checked) {
                        eyebrow.visibility = View.VISIBLE
                    }
                    else {
                        eyebrow.visibility = View.INVISIBLE
                    }
                }

                R.id.rambut -> {
                    val hair = findViewById<ImageView>(R.id.hair)
                    if (checked) {
                        hair.visibility = View.VISIBLE
                    }
                    else {
                        hair.visibility = View.INVISIBLE
                    }
                }
            }
        }
    }
}
