package com.papb.mrhead

import android.os.Bundle
import android.os.PersistableBundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.random.Random

class Recycler : AppCompatActivity(), View.OnClickListener {
    lateinit var recycler: RecyclerView
    lateinit var adapter: RecyclerViewAdapter
    lateinit var _kontakList: ArrayList<Kontak>
    lateinit var addData: Button
    var image = arrayOf(R.drawable.ava1, R.drawable.ava2, R.drawable.ava3, R.drawable.ava4)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.kontak)

        addData = findViewById(R.id.addData)
        addData.setOnClickListener(this)

        loadData()
        initRecyclerView()
    }

    private fun initRecyclerView() {
        recycler = findViewById<RecyclerView>(R.id.recyclerView)
        adapter = RecyclerViewAdapter(_kontakList, this)
        recycler.adapter = adapter
        recycler.layoutManager = GridLayoutManager(this, 3)
    }

    private fun addData() {
        var random = Random.nextInt(3)
        _kontakList.add(
            Kontak(
                "newData" + (_kontakList.size - 1),
                "08123456789" + (_kontakList.size - 1),
                image[random]
            )
        )
    }

    private fun loadData() {
        _kontakList = ArrayList()
        _kontakList.add(Kontak("Shifa", "081234567890", image[0]))
        _kontakList.add(Kontak("Akbar", "085648640046", image[1]))
        _kontakList.add(Kontak("Budi", "085648640047", image[2]))
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.addData -> {
                addData()
                adapter.notifyDataSetChanged()
            }
        }
    }
}